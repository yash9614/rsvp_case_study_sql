# SQL-RSVP-Case-Study
The given project is a MySQL project, I have used RSVP movies database to derive insightful results using all kinds of SQL queries right from Basics to Advance SQL for RSVP movie company and help them for their further planning and decision making for future projects
